nota1= int(input("Coloque sua primeira nota "))
nota2= int(input("Coloque sua segunda nota "))
peso1= nota1 * 6
peso2= nota2 * 4
somapeso= 6 + 4
somanota= peso1 + peso2
mediafinal= somanota / somapeso
print("A média ponderada final é", mediafinal)