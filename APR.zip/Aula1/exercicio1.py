x= int(input("Coloque um numero "))
print('O número escolhido foi', x)