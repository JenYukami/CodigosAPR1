x= int(input("Coloque um número "))
sucessor = x + 1
antecessor = x - 1
print("o sucessor do", x, "é", sucessor, "e o antecessor é", antecessor )