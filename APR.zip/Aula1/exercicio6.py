salarioinicial= int(input("Coloque seu salário "))
soma1= salarioinicial * 25
reajuste= soma1 / 100
salarionovo= salarioinicial + reajuste
print("O reajuste é de", reajuste)
print("O seu novo salário é", salarionovo)