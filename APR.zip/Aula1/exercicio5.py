x= int(input("Coloque o primeiro número "))
y= int(input("Coloque o segundo número ")) 
soma1= x ** 2 + y ** 2
soma2= x - y
soma3= soma2 ** 2
z= soma1/soma3
print("A soma de z é ", z)
