x= int(input("Coloque o primeiro número "))
y= int(input("Coloque o segundo número "))
print("Resultado", x * y)