'''Em geometria analítica, dois vetores podem ser definidos como a=<a1,a2,a3> e 
b=<b1,b2,b3>. Escreva um programa que leia dois vetores a e b (duas listas) de 
três posições cada e efetue o produto escalar entre eles. O produto escalar é obtido 
por ab = a1b1+a2b2+a3b3. De acordo com o exemplo dado abaixo, o calculo a ser 
efetuado será: 1x5+4x2+7x3'''

#Começar a lista a vazia
a = []
posicao = 3
cont = 0


while cont < posicao:
    valor = int(input("Digite um valor "))
    a.append(valor)
    cont += 1
print(a)

#Começar a lista b vazia
b = []
posicao
cont = 0
while cont < posicao:
    valor = int(input('Digite um valor '))
    b.append(valor)
    cont += 1
print(b)

#Criar o produto escalar
