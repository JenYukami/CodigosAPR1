''' Crie uma função recursiva para retornar a quantidade 
de caracteres de uma string'''

def quantidade(palavra, i):
    if i == 0:
        return 0
    else:
        return 1 + quantidade(palavra, i - 1)

def main():
    palavra = input('Digite uma palavra: ')
    result = quantidade(palavra, len(palavra) - 1)
main()