'''Faça uma função recursiva para calcular o quociente 
da divisão inteira.'''

def quociente(x,y):
    if x < y:
        return 0
    else:
        return 1 + quociente(x - y, y)
    
def main():
    x = int(input('Me dê o primeiro valor: '))
    y = int(input('Me dê o segundo valor: '))
    result = quociente(x,y)
    print(f'Resultado do quociente {x} / {y} = {result}')
main()