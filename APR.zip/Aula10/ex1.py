'''Faça uma função recursiva para encontrar a
potência positiva (n>=0) de um número X'''

def POT(base, expoente ):
    if expoente == 0:
        return 1
    elif expoente > 0:
        return expoente * POT(base, expoente - 1)
    
def main():    
    base = int(input('Informe um valor para base: '))
    expoente = int(input('Informe um valor para o expoente: '))
    result = POT(base, expoente)
    print(f'Potencia de {base} ^ {expoente} = {result}')
main()