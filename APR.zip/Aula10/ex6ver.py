def vertical(palavra, i):
    if i == len(palavra) - 1:
        print(palavra[i])
    else:
        print(palavra[i])
        vertical(palavra, i + 1)

def main():
    palavra = input('Digite uma palavra: ')
    i = 0
    vertical(palavra, i)
    

main()