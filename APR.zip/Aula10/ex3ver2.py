def soma(lista, k):
    if k == 0:
        return lista[k]
    elif k > 0 and k < len(lista):
        return soma(lista, k-1) + lista[k]
    
def main():
    L = [1,2,3,4,5]
    result = soma(L, len(L) - 1)
    print(f'Soma = {result}')
main()