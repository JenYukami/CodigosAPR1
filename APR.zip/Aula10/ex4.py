'''Faça uma função recursiva para calcular o
MDC entre dois números x e y. Considere:
mdc(x; y) = y, se x >= y e x mod y = 0
 mdc(x; y) = mdc(y; x), se x < y
mdc(x; y) = mdc(y; x mod y), caso contrario'''

def MDC(x, y):
    if x >= y and x % y == 0:
        return y
    elif x < y:
        return MDC(y, x)
    elif x < y:
        return MDC(y, x % y)
    

def main():
    x = int(input('Informe o primeiro valor: '))
    y = int(input('Informe o segundo valor: '))
    result = MDC(x,y)
    print(f'O reultado do MDC é {result}')
main()