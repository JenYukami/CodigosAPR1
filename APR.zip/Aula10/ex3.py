''' Faça uma função recursiva para encontrar a
soma dos elementos de uma lista L de
tamanho n.
– Se definirmos a soma dos valores de L por s(k),
com indices de 0 a k (L[0..k]), podemos escrever:
s(0) = L[0]
s(k) = s(k-1) + L[k], 1 <= k < n'''

def SOMA(L, K):
    if K == 0:
        return L[0]
    else:
        return SOMA(L, K - 1) + L[K]


def main():
    N = int(input('Informe um valor'))
    L = []

    for i in range(N):
        L.append(int(input(f'Informe o valor {i + 1}: ')))

    result = SOMA(L, N - 1)
    print(f'A soma dos elementos da lista é: {result}')
main()