'''Crie uma função recursiva que exiba verticalmente 
uma string'''

def vertical(palavra):
    if palavra == '':
        return 0
    else:
        print(palavra[0])
        vertical(palavra[1:])

def main():
    palavra = input('Digite uma palavra: ')
    vertical(palavra)
main()