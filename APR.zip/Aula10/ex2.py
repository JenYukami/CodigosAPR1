'''Faça uma função recursiva para calcular o
resto da divisão inteira.'''

def DIV(n,x):
    if n < x:
        return n
    
    else:
        return DIV(n - x, x)


def main():
    n = int(input('Informe o valor: '))
    x = int(input('Informe o divisor: '))
    result = DIV(n, x)
    print(f'o valor dessa conta {n} / {x} = {result}')
main()
