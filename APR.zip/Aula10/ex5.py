''' Crie uma função recursiva para retornar a quantidade 
de caracteres de uma string'''

def caracter(palavra):
    if palavra == '':
        return 0
    else:
        return 1 + caracter(palavra[1:])

def main():
    palavra = input('Digite uma palavra: ')
    result = caracter(palavra)
    print(f'Tem {result} caracteres')
main()