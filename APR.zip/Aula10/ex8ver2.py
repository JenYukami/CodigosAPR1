'''Função recursiva que exibe uma string na ordem 
inversa'''

def inversa(palavra, i):
    if i == 0:
        print(palavra[i])
    else:
        print(palavra[i], end = '')
        inversa(palavra, i - 1)

def main():
    palavra = input('Digite uma palavra: ')
    inversa(palavra, len(palavra) - 1)
main()