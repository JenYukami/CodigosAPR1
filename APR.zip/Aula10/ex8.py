'''Função recursiva que exibe uma string na ordem 
inversa'''

def inversa(palavra):
    if palavra == '':
        return ''
    else:
        return palavra[-1] + inversa(palavra[:-1])

def main():
    palavra = input('Digite uma palavra: ')
    result = inversa(palavra)
    print(f'A palavra inversa de {palavra} é {result}')
main()