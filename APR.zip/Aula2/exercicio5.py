a = int(input("Digite o primeiro valor: "))

if a != 0:
    b = int(input("Digite o segundo valor: "))
    c = int(input("Digite o terceiro valor: "))
    delta = b ** 2 - 4 * a * c
    if delta < 0:
        print("Não existe raíz")
    elif delta == 0:
        x = -b/(2*a)
        print("Existe uma raiz=", x)
    else:
        x1 = (-b + (delta**0.5))/ (2*a)
        x2 = (-b - (delta**0.5))/ (2*a)
        print("Raíz 1:", x1, "Raíz 2: ", x2)
else: 
    print("valor de a tem que ser diferente de 0")