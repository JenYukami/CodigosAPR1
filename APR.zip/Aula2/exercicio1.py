num1= int(input("Digite primeiro valor: "))
num2= int(input("Digite segundo valor: "))
num3= int(input("Digite terceiro valor: "))
num4= int(input("Digite quarto valor: "))
num5= int(input("Digite quinto valor: "))
maior = num1

if num2 > maior:
    maior = num2
elif num3 > maior:
    maior = num3
elif num4 > maior:
    maior = num4
elif num5 >maior:
    maior = num5

print("O número maior entre eles é", maior)
