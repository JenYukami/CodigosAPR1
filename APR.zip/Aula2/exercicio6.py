valor = int(input("Digite o valor da compra: R$ "))

if valor <= 100:
    desconto = valor * 0.05
elif valor < 200:
    desconto = valor * 0.10
else:
    desconto = valor * 0.20

valor_final = valor - desconto

print("Desconto aplicado: R$", desconto)
print("Valor a pagar: R$", valor_final)