a = int(input("Digite o primeiro valor: "))
b = int(input("Digite o segundo valor: "))
c = int(input("Digite o terceiro valor: "))

if a < b + c and b < a + c and c < a + b:
  if a == b == c:
    print("Triângulo Equilátero")
  elif a == b or b == c or c == a:
    print("Triângulo Isósceles")
  else:
    print("Triângulo Escaleno")

else:
 print("Não é um triângulo")