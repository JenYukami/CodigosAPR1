ref_arq = open('estudante_teste.txt','r')
for linha in ref_arq:
    print(linha)