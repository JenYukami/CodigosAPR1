def Existe_Arquivo(nome):
    import os
    if os.path.exists(nome):
        return True
    else:
        return False