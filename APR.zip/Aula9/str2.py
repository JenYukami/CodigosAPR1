alunos = [['sc1111', 'Elaine Silva', 'elaine@mail.com'],
    ['sc2222','Mario Sérgio', 'mario@mail.com'],
    ['sc3333','Luciana Maria', 'luma@mail.com']]
nome = './Dados_alunos.txt'
ref_arq = open(nome, 'w')#abre um arquivo no modo de escrita

for i in range(len(alunos)):
    registro_aluno = ''
    for j in range(len(alunos[i])):
        registro_aluno += alunos[i][j] + ';'
    registro_aluno += '\n'
    ref_arq.write(registro_aluno)