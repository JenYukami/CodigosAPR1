#Faça um programa em Python que leia um conjunto de valores
#correspondentes às notas que os alunos obtiveram em uma prova de
#Algoritmos. Quando o valor fornecido for um número negativo, significa
#que não existem mais notas para serem lidas. Após isso seu programa
#deverá:
# Escrever quantas notas são maiores ou iguais a 6.0
# Escrever quantas notas são maiores ou iguais a 4.0 e menores que 6.0
# Escrever quantos notas são menores que 4.0
# Escrever a média das notas fornecidas pelo usuário.

maiorigual6 = 0
entre4e6 = 0
menor4 = 0
soma = 0
quantidade = 0
nota1 = float(input('Digite sua nota: '))

while nota1 >= 0:
    if nota1 >= 6:
        maiorigual6 += 1
    elif nota1 >= 4:
        entre4e6 += 1
    else:
        menor4 += 1
    
    soma += nota1
    quantidade += 1
    
    nota1 = float(input('Digite sua nota: '))

media = soma / quantidade

print(f"Notas maiores ou iguais a 6.0: {maiorigual6}")
print(f"Notas entre 4.0 e 6.0: {entre4e6}")
print(f"Notas menores que 4.0: {menor4}")
print(f"Média das notas: {media:.2f}")