#Faça um programa que mostre os 8 primeiros termos da sequência de
#Fibonacci. Ex: 0, 1, 1, 2, 3, 5, 8,13, 21,34, 55...

a = 0
b = 1
contador = 0

while contador < 8:
    print(a)
    
    proximo = a + b
    a = b
    b = proximo
    
    contador += 1