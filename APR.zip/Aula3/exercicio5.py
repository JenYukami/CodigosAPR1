#Faça um programa que receba um número inteiro maior que 1,
#verifique se o número é primo ou não e mostre a mensagem de
#número primo ou de número não primo. Obs: Um número é primo
#quando é divisível apenas por 1 e por ele mesmo

num = int(input("Digite um número: "))
primo = True

for divisão in range(2, num):
    if num % divisão == 0:
        primo = False

if primo:
    print(f"{num} é primo")
else:
    print(f"{num} não é primo")