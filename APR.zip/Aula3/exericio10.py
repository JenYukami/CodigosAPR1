n = int(input("Digite quantos termos você quer: "))

soma = 0
k = 1

while k <= n:
    termo = k / (2*k - 1)
    print(termo)
    soma += termo
    k += 1

print(f"A soma da série é: {soma:.2f}")