#Faça um programa que exiba todos os números de 1 a 100 que são divisíveis por 7 e por 3.
x = 0
while x <= 100:
    if x % 7 == 0 and x % 3 == 0:
       print('divisiveis por 7 e 3:', x)
    x+=1
