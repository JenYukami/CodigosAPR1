#Faça um programa para mostrar as tabuadas de todos os números de 1 a 10.
x = 1
while x <= 10:
    cont= 1
    while cont <=10:
        print (f'{x}*{cont}={x*cont}')
        cont += 1
print('***************')
x += 1