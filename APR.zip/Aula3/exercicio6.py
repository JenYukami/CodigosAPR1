#Faça um programa em Python que receba dois valores inteiros,
#representando a base e o expoente. O programa deverá calcular e
#apresentar o resultado da base elevada ao expoente. Por exemplo, para
#base = 5 e expoente = 3, ou seja, 53
#, o programa deverá imprimir 125.
# Obs: não utilize o operador de exponenciação (**). Utilize somente estrutura de repetição

base = int(input('Digite o  valor da base: '))
expoente = int(input('Digite o valor do expoente: '))
resultado = 1

for i in range(expoente):
    resultado = resultado * base

print(f"{base}^{expoente}= {resultado}")