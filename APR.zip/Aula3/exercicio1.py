#Faça um programa que exiba todos os números de 1 a 100 que são divisíveis por 7.

soma = 0
for soma in range(1, 101):
    if soma % 7 == 0:
        print(soma)
    soma += 1
