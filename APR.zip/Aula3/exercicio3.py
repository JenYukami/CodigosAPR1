#Faça um programa para mostrar a tabuada de um número qualquer fornecido pelo usuário. Por exemplo, se o número fornecido for igual a 3, o programa de apresentar a seguinte saída:
x = 1
num = int(input("Digite um numero: "))
while x <= 10:
    resultado = x * num
    print(x, 'X ', num, "=", resultado)
    x += 1