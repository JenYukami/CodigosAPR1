numero = int(input("Digite um número inteiro: "))

resultado = 1
contador = numero

while contador > 0:
    resultado = resultado * contador
    contador -= 1

print(f"O fatorial de {numero} é {resultado}")