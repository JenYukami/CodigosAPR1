def calcular_media(notas):
    i = 0
    total = 0
    if len(notas) == 0:
        return 0
    while i < len(notas):
        total = total + notas[i]
        i+=1

    dividir = total/i
    return dividir

def situacao_aluno(media):
    if media >= 6:
        return aprovado
    if media 4 


def main():
    notas = []
    nota = input('Digite sua nota: ')
    while nota != '':
        notas.append(float(nota))
        nota = input('Digite sua nota: ')

    media = calcular_media()



main()
