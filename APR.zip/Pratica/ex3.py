idade = int(input('Digite sua idade: '))

while idade < 0 or idade > 120:
    print("idade invalida, tente novamente")
    idade = int(input('Digite sua idade: '))
    
print(f'Idade registrada: {idade}')