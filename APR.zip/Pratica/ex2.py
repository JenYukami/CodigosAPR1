num = int(input('Digite um numero '))
qnt = 0
soma = 0 
while num > 0:
    soma = soma + num
    qnt += 1
    num = int(input())
print(soma/qnt)
print(qnt)