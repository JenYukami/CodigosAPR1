n = int(input('informe um numero: '))
soma = 0
i = 1
while i <= n :
    soma = soma + i #um acumulador
    i = i + 1 
print(f'Valor do  somatorio: {soma}')