'''Crie um programa que preencha uma matriz 3x3 de números inteiros e verifique
se essa matriz forma um quadrado mágico. Um quadrado mágico é formado
quando a soma dos elementos de cada linha é igual:
- à soma dos elementos de cada coluna da matriz;
- à soma dos elementos da diagonal principal;
- à soma dos elementos da diagonal secundária; '''

matriz = []
m = 3
n = 3
lin = 0

while lin < m:
    linha = []
    col = 0
    print(f'Digite um valor para linha: {lin}')
    while col < n:
        valor = int(input(' '))
        linha.append(valor)
        col += 1
    matriz.append(linha)
    lin += 1

for lin in range(len(matriz)):
    for col in range(len(matriz[lin])):
        print(matriz[lin][col], end = ' ')
    print()

lin = 0
somalinha = []
while lin < m:
  
    soma_lin = 0
    col = 0
    while col < n:
        soma_lin += matriz[lin][col]
        col += 1
    print(f'Soma dos valores da linha: {soma_lin}')
    somalinha.append(soma_lin)
    lin += 1


col = 0
somacoluna = []
while col < n:
    soma_col = 0
    lin = 0
    while lin < m:
        soma_col += matriz[lin][col]
        lin += 1
    print(f'Soma dos valores da colunas: {soma_col}')
    somacoluna.append(soma_col)
    col += 1

#Soma da diagonal primaria e secundaria
soma_diagonal1 = matriz[0][0] + matriz[1][1] + matriz[2][2]
soma_diagonal2 = matriz[0][2] + matriz[1][1] + matriz[2][0]

print(f'Soma da diagonal primaria: {soma_diagonal1}')
print(f'Soma da diagonal secundaria: {soma_diagonal2}')

referencia = somalinha[0]

if (somalinha[1] == referencia and
    somalinha[2] == referencia and
    somacoluna[0] == referencia and
    somacoluna[1] == referencia and
    somacoluna[2] == referencia and
    soma_diagonal1 == referencia and
    soma_diagonal2 == referencia):
    print('É um quadrado mágico!')
else:
    print('Não é um quadrado mágico.')