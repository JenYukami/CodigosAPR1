pesos = float(input('What do you have left in pesos? '))
soles = float(input('What do you have left in soles '))
reais = float(input('What do you have left in reais? '))
pesosdolar = pesos * (56/1000)
solesdolar = soles * 0,29
reaisdolar = reais * 0,1927

soma = pesosdolar + solesdolar + reaisdolar

print(soma)
