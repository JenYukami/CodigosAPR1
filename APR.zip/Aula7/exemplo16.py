nro_ok=False
while not nro_ok:
    nro=input("Digite um número inteiro positivo: ")
    nro_ok=nro.isdigit()
    if not nro_ok:
        print("O valor digitado não é um número inteiro positivo!")
nro=int(nro) #faz a conversão
print("O valor digitado é: ",nro)