nome = "Eloize Seno"
novo_nome = nome[:len(nome) - 1] + 'a'
print(novo_nome)