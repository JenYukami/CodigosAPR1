fruta = "apple"
i = 0
while i < len(fruta):
 print(fruta[i])
 i += 1
