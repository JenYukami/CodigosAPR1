frase = ""
frase = frase + "Essa string usa "
meio = '"apóstrofes" '
frase = frase + meio
fim = "como demarcador. "
frase = frase + fim
print(frase)