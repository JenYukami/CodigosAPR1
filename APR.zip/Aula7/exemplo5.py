texto = "Essa é uma 'string'"
print(texto)
texto[2] = 'S'
print(texto)

###As strings são algo imutaveis ou seja não pode mudar o valor do caractere###