'''Crie uma função que receba como parâmetro um número inteiro. A função
deve retornar um número inteiro, conforme a seguir:
a) Retornar 1 se o número recebido é positivo
b) Retornar -1 se o número recebido é negativo
c) Retornar 0 se o número recebido é zero'''