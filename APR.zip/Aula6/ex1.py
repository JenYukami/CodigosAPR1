'''Faça uma função InteiroPositivo(n) que verifica se uma string fornecida como
parâmetro pode ser convertida para um número inteiro positivo. A função deverá
retornar True em caso afirmativo e False, caso contrário. O programa principal deverá
fazer a conversão para inteiro, caso o resultado da função seja True, ou imprimir a
mensagem adequada, caso o resultado seja False'''


def inteiropositivo(n):
    return n.isdigit() and int(n) > 0

def main():
    numero=input("Digite um número inteiro positivo: ")
    if inteiropositivo(numero):
        numero = int(numero)
        print(f'{numero} é um número inteiro positivo')
    else:
        print('O valor digitado não é um número inteiro positivo')
main()