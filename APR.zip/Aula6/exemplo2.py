def double_stuff(lista):
    nova_lista = []
    for valor in lista:
        novo_elemento = 2 * valor
        nova_lista.append(novo_elemento)
    return nova_lista

things = [2, 5, 9]
print(things)


dobra = double_stuff(things)
print(dobra)
