'''Faça uma função Inteiro(n) que verifica se uma string fornecida como parâmetro
pode ser convertida para um número inteiro positivo ou negativo. A função deverá
retornar True em caso afirmativo e False, caso contrário. O programa principal deverá
fazer a conversão para inteiro, caso o resultado da função seja True, ou imprimir a
mensagem adequada, caso o resultado seja False.'''

def inteiro(n):
    return n.isdigit() 

def main():
    numero = input('Digite um valor inteiro: ')
    if inteiro(numero) >= 0 or inteiro(numero) <= 0:
        numero = int(numero)
        print(f'{numero} é um valor inteiro')
    else:
        print('Não é um valor inteiro')

main()