VAR_GLOBAL = 'Variavel definida fora da função'
def imprimir_frase():
    VAR_GLOBAL = 'Variavel definida na função imprimir_frase'
    print('Variavel global: ', VAR_GLOBAL)
    print('Variavel local:', VAR_GLOBAL)
print('Executando a funçao escreve_texto:' )

####PROGRAMA PRINCIPAL####
imprimir_frase()
print('Tentando acessar a variavel global no programa:')
print('Variavel global: ', VAR_GLOBAL)
print('Tentando acessar a variavel local no programa:')
print('Variavel local:', VAR_GLOBAL)