def apresentar():
    print('Ola, bem vindo!')
    print('Esse é o meu programa!')

def despedir():
    print('Espero que tenha gostado')
    print('Obrigado por usar o meu programa')
#######PROGRAMA PRINCIPAL#######
print('inicio')
apresentar()
print('Programa em execução')
despedir()
print('Fim!')
