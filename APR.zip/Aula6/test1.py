def somar(x,y): #####prototipo, tem parametros#####
    result = x + y
    return result #####Invés de colocar o print, retorna o valor,porém agora tera que criar uma variavel(não necessariamente)#####

def dividir(x,y):   #####prototipo, tem parametros#####
    if y != 0:
        return x/y

def multiplicar(x, y): #####Não tem parametros######
    return x * y


def main():
   re = somar(33, 45)
   print(re)
   a = 128
   b = 5
   print(dividir(a,b))
   print(multiplicar(a,b))
#####PGM PRINCIPAL#####
main()


def multiplicar(): #####Não tem parametros######
    x = int(input('Entre o primeiro valor '))
    y = int(input('Entre o segundo o valor '))
    return x * y

print(multiplicar())