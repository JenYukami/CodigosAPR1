def somar(x,y):
    return x + y

def subtração(x, y):
    return x - y

def multiplicar(x,y):
    return x * y

def dividir(x,y):
    if y != 0:
        return x/y

def exponencial(x,y):
    return x ** y

def main():
   re = somar(33, 45)
   print(re)
   a = 128
   b = 5
   print(dividir(a,b))
   print(multiplicar(a,b))
   print(exponencial(a,b))
   print(subtração(a,b))
#####PGM PRINCIPAL#####
main()
 