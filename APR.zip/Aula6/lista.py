
def troca(lista): ####l é chamada aqui de lista
    print(lista)
    num = int(input('Entre com um valor qualquer: '))
    lista[2] = num ####Vai trocar o numero dessa posição


def main():
    l = [1,2,3,4,5]
    troca(l)
    print(l)


####PGM MAIN####
main()