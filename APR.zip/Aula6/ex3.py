''' Faça uma função Real(n) que verifica se uma string fornecida como parâmetro pode
ser convertida para um número real. A função deverá retornar True em caso
afirmativo e False, caso contrário. O programa principal deverá fazer a conversão para
inteiro, caso o resultado da função seja True, ou imprimir a mensagem adequada,
caso o resultado seja False'''

def real(n):
    return n.isdigit()

def main():
    numero = input('Digite um número real: ')
    if real(numero) > 0 or not float(numero):
        numero = int(numero)
        print('É um número real')
    else:
        print('Não é um número real')

main()