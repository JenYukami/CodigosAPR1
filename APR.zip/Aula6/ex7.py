def interseccao(listaA, listaB):
    listaC = [] #variavel local da função
    for i in range(len(listaA)):
        for j in range(len(listaB)):
            if listaA[i] == listaB[j]:
                listaC.append(listaA[i])
    return listaC

def uniao(listaA, listaB):
    listaC = []
    for i in range(len(listaA)):
        listaC.append(listaA[i])
    for i in range(len(listaB)):
        encontrou = False
        for j in range(len(listaC)): 
            if listaB[i] == listaC[j]:
                encontrou = True
        if encontrou == False:
            listaC.append(listaB[i])
    return listaC


def subtracao(listaA,listaB):
    listaC = []
    for i in range(len(listaA)):
        encontrou = False
        for j in range(len(listaB)):
            if listaA[i] == listaB[j]:
                encontrou = True
        if encontrou == False:
            listaC.append(listaA[i])
            
    return listaC
    

def criar_lista(tam):
    print(f'Digite {tam} valores inteiros para a lista')
    lista = [] #variavel local da função
    i = 0
    while i < tam:
        valor = int(input())
        lista.append(valor)
        i += 1
    return lista

def imprimir_lista(lista):
    for i in range(len(lista)):
        print(f'{lista[i]}', end = ' ')
    print()

def menu():
    print('Menu de opções:')
    print('1. Intersecção de listas')
    print('2. União de listas')
    print('3. Substração de listas')
    print('4. Sair')
    op = int(input('Escolha uma opção entre 1 e 3 ou digite 4 para sair: '))
    return op

def main():
    #chama a função que apresenta um menu de usuarios
    opcao = 1
    #chama a função criar_lista que cria uma lista com 7 elementos
    l1 = criar_lista(3)
    #chama a função que imprime os elementos da lista
    imprimir_lista(l1) 
    l2 = criar_lista(3)
    imprimir_lista(l2)


    while opcao != 4:
        opcao = menu()
        if opcao == 1:
            print('Intersecção de listas...')
            #Incluir aqui a chamada da função que faz a intersecção das listas
            l3 = interseccao(l1,l2)
            imprimir_lista(l3)
        elif opcao == 2:
            print('União de listas...')
            #Incluir aqui a chamada da função que faz a União das listas
            l4 = uniao(l1,l2)
            imprimir_lista(l4)
        elif opcao == 3:
            print('Subtração de listas...')
            #Incluir aqui a chamada da função que faz a Subtração das listas
            l5 = subtracao(l1,l2)
            imprimir_lista(l5)
        elif opcao == 4:
            print('Encerrando o programa.')
        else:
            print('Opção inválida!')
main()

####Chamada da função main()####
