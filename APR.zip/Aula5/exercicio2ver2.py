matriz = [] #Matriz A
lin = 0

while lin < 3:
    linha = [] #Guarda os elementos da colunas da linha lin
    col = 0
    print(f'Digite os valores da linha {lin}')
    #Monta a linha toda, quando termina a repetição do laço
    while col < 2:
        valor = int(input(''))
        linha.append(valor)
        col += 1
    matriz.append(linha)
    lin += 1
#imprimindo a matriz original
print('Matriz original: ')
for i in range(len(matriz)):
    for j in range(len(matriz[i])):
        print(matriz[i][j], end= ' ')
    print() #Escreve a proxima linha evitando ficar na mesma linha
#Construindo a Matriz transposta
transposta = []
j = 0

while j < len(matriz[0]):  #Percorre cada coluna, matriz 0 representa o valor da linha 0
     i = 0
     linha = []
     while i < len(matriz):
         linha.append(matriz[i][j])
         i += 1
     transposta.append(linha)
     j += 1

print('Matriz transposta: ')
#imprimindo a matriz transposta
for i in range(len(transposta)):
    for j in range(len(transposta[i])):
        print(transposta[i][j], end = ' ')
    print()