matriz = []  
n = int(input('Informe a dimensão N da matriz quadrada: '))
lin = 0

while lin < n:  
    linha = []  
    col = 0
    print(f'Digite os valores da linha {lin}: ')
    while col < n: 
        valor = int(input())
        linha.append(valor)
        col += 1
    matriz.append(linha)
    lin += 1


transposta = []
i = 0
while i < n:
    linha_t = []
    j = 0
    while j < n:
        linha_t.append(matriz[j][i]) 
        j += 1
    transposta.append(linha_t)
    i += 1


simetrica = True
lin = 0
while lin < n:
    col = 0
    while col < n:
        if matriz[lin][col] != transposta[lin][col]:
            simetrica = False
        col += 1
    lin += 1


print('\nMatriz original (A):')
for lin in range(len(matriz)):
    for col in range(len(matriz[lin])):
        print(matriz[lin][col], end=' ')
    print()


print('\nMatriz transposta (At):')
for lin in range(len(transposta)):
    for col in range(len(transposta[lin])):
        print(transposta[lin][col], end=' ')
    print()


print()
if simetrica:
    print('A matriz A é SIMÉTRICA.')
else:
    print('A matriz A NÃO é simétrica.')