matriz = []
n = int(input('Informe um valor de linhas: '))
m = int(input('Informe um valor de coluna: '))
lin = 0
maior = 0
menor = 0

while lin < n:
    linha = []
    col = 0
    print(f'Digite os valores da {lin}')
    while col < m:
        valor = int(input())
        linha.append(valor)
        col += 1
    matriz.append(linha)
    lin += 1

maior = matriz[0][0]
menor = matriz[0][0]

for lin in range(len(matriz)):
    for col in range(len(matriz[lin])):
            if matriz[lin][col] > maior:
                 maior = matriz[lin][col]
            if matriz[lin][col] < menor:
                 menor = matriz[lin][col]

print(f'Maior elemento: {maior}')
print(f'Menor elemento: {menor}')
