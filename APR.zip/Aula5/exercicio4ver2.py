matriz = []
m = int(input('Entre com o numero de linhas da matriz '))
n = int(input('Entre com o numero de colunas da matriz '))
lin = 0
#Construção da Matriz
while lin < m:
    linha = [] #Guarda os elementos da colunas da linha lin
    col = 0
    print(f'Digite os valores da linha {lin}')
    #Monta a linha toda, quando termina a repetição do laço
    while col < n:
        valor = int(input(''))
        linha.append(valor)
        col += 1
    matriz.append(linha)
    lin += 1
#Identificar as linhas nulas
cont_lin_nula = 0 #Contador de linhas nulas
for i in range(len(matriz)):
    nula = True
    for j in range(len(matriz[i])):
        if matriz[i][j] != 0:
            nula =  False
    if nula:
        cont_lin_nula += 1
print(f'Total de linhas nulas = {cont_lin_nula}')

#Identificar as colunas nulas
contcol = 0
for j in range(len(matriz[0])):
    nula = True
    for i in range(len(matriz)):
        if matriz[i][j] != 0:
            nula = False
    if nula:
        contcol += 1
print(f'Total de colunas nulas = {contcol}')