# Lendo a matriz A (dimensão m x n)
matrizA = []
m = int(input('Informe a quantidade de linhas da matriz A: '))
n = int(input('Informe a quantidade de colunas da matriz A: '))
lin = 0

while lin < m:
    linha = []
    col = 0
    print(f'Digite os valores da linha {lin} de A: ')
    while col < n:
        valor = int(input())
        linha.append(valor)
        col += 1
    matrizA.append(linha)
    lin += 1

# Lendo a matriz B (dimensão n x q)
# Obs: o número de linhas de B deve ser igual ao número de colunas de A (n)
matrizB = []
print(f'\nA matriz B deve ter {n} linhas (para ser possível multiplicar A x B)')
q = int(input('Informe a quantidade de colunas da matriz B: '))
lin = 0

while lin < n:
    linha = []
    col = 0
    print(f'Digite os valores da linha {lin} de B: ')
    while col < q:
        valor = int(input())
        linha.append(valor)
        col += 1
    matrizB.append(linha)
    lin += 1

# Criando a matriz produto C (dimensão m x q)
matrizC = []
lin = 0
while lin < m:
    linha_c = []
    col = 0
    while col < q:
        soma = 0
        k = 0
        while k < n:  # percorre os elementos que serão multiplicados e somados
            soma += matrizA[lin][k] * matrizB[k][col]
            k += 1
        linha_c.append(soma)
        col += 1
    matrizC.append(linha_c)
    lin += 1

# Imprimindo a matriz A
print('\nMatriz A:')
for lin in range(len(matrizA)):
    for col in range(len(matrizA[lin])):
        print(matrizA[lin][col], end=' ')
    print()

# Imprimindo a matriz B
print('\nMatriz B:')
for lin in range(len(matrizB)):
    for col in range(len(matrizB[lin])):
        print(matrizB[lin][col], end=' ')
    print()

# Imprimindo a matriz C (produto de A x B)
print('\nMatriz C (produto de A x B):')
for lin in range(len(matrizC)):
    for col in range(len(matrizC[lin])):
        print(matrizC[lin][col], end=' ')
    print()