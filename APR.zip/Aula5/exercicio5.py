'''Escreva um programa que leia inicialmente os elementos de 2
matrizes A e B, sendo A de dimensão m x n e B de dimensão n x q. O
programa deverá criar uma matriz C (conforme o exemplo a seguir),
representando a matriz produto entre A e B. Ao final, o programa
deve mostrar as três matrizes. OBS: Lembre-se de que o número de
colunas de A deve ser igual ao número de linhas de B.'''

matrizA = []
m = int(input('Digite um numero de colunas: '))
n = int(input('Digite um numero de linhas: '))
lin = 0

while lin < m:  
    linha = [] 
    col = 0
    print(f'Digite os valores da linha {lin}: ')
    while col < n:  
        valor = int(input())
        linha.append(valor)
        col += 1
    matrizA.append(linha)
    lin += 1
print('MatrizA: ')
for i in range(len(matrizA)):
    for j in range(len(matrizA[i])):
        print(matrizA[i][j], end= ' ')
    print()

#Construindo a Matriz B
# Obs: o número de linhas de B deve ser igual ao número de colunas de A (n)
matrizB = []
q = int(input("Digite numero de colunas: "))
lin = 0

while lin < n:
    linha = []
    col = 0
    print(f'Digite o valor da linha {lin}: ')
    while col < q:
        valor = int(input())
        linha.append(valor)
        col += 1
    matrizB.append(linha)
    lin += 1

print('MatrizB: ')
for i in range(len(matrizB)):
    for j in range(len(matrizB[i])):
        print(matrizB[i][j], end= ' ')
    print()

#Construindo a Matriz C
matrizC = []
lin = 0
while lin < m:
    linhaC = []
    col = 0
    while col < q:
        soma = 0
        k = 0
        while k < n:
            soma += matrizA[lin][k] * matrizB[k][col]
            k += 1
        linhaC.append(soma)
        col += 1
    matrizC.append(linhaC)
    lin += 1

print('MatrizC: ')
for i in range(len(matrizC)):
    for j in range(len(matrizC[i])):
        print(matrizC[i][j], end= ' ')
    print()




