matriz = []
N = int(input('Entre com o numero de linhas da matriz '))
M = int(input('Entre com o numero de colunas da matriz '))
lin = 0
#Construção da Matriz
while lin < N:
    linha = [] #Guarda os elementos da colunas da linha lin
    col = 0
    print(f'Digite os valores da linha {lin}')
    #Monta a linha toda, quando termina a repetição do laço
    while col < M:
        valor = int(input(''))
        linha.append(valor)
        col += 1
    matriz.append(linha)
    lin += 1

#Encontrando o maior valor da matriz
maior = matriz[0][0] #A gente pega o primeiro valor para comparar a matriz toda

for i in range(len(matriz)):
    for j in range(len(matriz[i])):
        if matriz[i][j] > maior:
            maior = matriz[i][j]

print(f'Maior elemento = {maior}')

#Encontrando o menor valor da matriz
menor =[0][0]
i = 0

while i < len(matriz):
    j = 0
    while j < len(matriz(i)):
        if matriz[i][j] < menor:
            menor = matriz[i][j]
        j += 1
    i += 1
print(f'Menor elemento = {menor}')
