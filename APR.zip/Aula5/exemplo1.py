matriz = [] #Começo de uma matriz vazia o inicial dele
n = int(input('Informe a quantidade de linha da matriz '))
m = int(input('Informe a quantidade de coluna da matriz '))
lin = 0

while lin < n: #Para cada linha da matriz
    linha = [] #Começa sempre vazia inicialmente
    col = 0
    print(f'Digite os valores da linha {lin}: ')
    while col < m: #Para cada coluna da matriz
        valor = int(input())
        linha.append(valor)
        col+=1
    matriz.append(linha)
    lin+=1
#imprimindo a matriz
for lin in range(len(matriz)):
    for col in range(len(matriz[lin])):
        print(matriz[lin][col], end=' ')
    print()
