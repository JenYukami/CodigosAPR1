matriz = []  
n = 3  
m = 2  
lin = 0

while lin < n:  
    linha = [] 
    col = 0
    print(f'Digite os valores da linha {lin}: ')
    while col < m:  
        valor = int(input())
        linha.append(valor)
        col += 1
    matriz.append(linha)
    lin += 1

# Criando a matriz transposta (dimensões m x n)
transposta = []
i = 0
while i < m: 
    linha_t = []
    j = 0
    while j < n:  # e n colunas
        linha_t.append(matriz[j][i])  
        j += 1
    transposta.append(linha_t)
    i += 1

# Imprimindo a matriz original
print('\nMatriz original (A):')
for lin in range(len(matriz)):
    for col in range(len(matriz[lin])):
        print(matriz[lin][col], end=' ')
    print()

# Imprimindo a matriz transposta
print('\nMatriz transposta (At):')
for lin in range(len(transposta)):
    for col in range(len(transposta[lin])):
        print(transposta[lin][col], end=' ')
    print()