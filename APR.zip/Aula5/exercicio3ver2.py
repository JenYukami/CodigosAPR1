N = int(input('Entre com o numero de linhas e colunas da matriz: '))
matriz = []
lin = 0

while lin < N:
    linha = [] #Guarda os elementos da colunas da linha lin
    col = 0
    print(f'Digite os valores da linha {lin}')
    #Monta a linha toda, quando termina a repetição do laço
    while col < N:
        valor = int(input(''))
        linha.append(valor)
        col += 1
    matriz.append(linha)
    lin += 1
#verificando se a matriz é simetrica
simetrica = True
i = 0
while i < N:
    j = 0
    while j < N and simetrica:
        if matriz[i][j] != matriz[j][i]: #Faz sentindo mudar quando a matriz não for simetrica
            simetrica = False

        j += 1
    i += 1
if simetrica:
   print('Matriz Simetrica')
else:
    print('Matriz não é simetrica')
