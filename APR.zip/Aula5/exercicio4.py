matriz = []  # Começo de uma matriz vazia o inicial dele
m = int(input('Informe a quantidade de linhas da matriz: '))
n = int(input('Informe a quantidade de colunas da matriz: '))
lin = 0

while lin < m:  # Para cada linha da matriz
    linha = []  # Começa sempre vazia inicialmente
    col = 0
    print(f'Digite os valores da linha {lin}: ')
    while col < n:  # Para cada coluna da matriz
        valor = int(input())
        linha.append(valor)
        col += 1
    matriz.append(linha)
    lin += 1

# Contando linhas nulas (todos os elementos da linha são zero)
linhas_nulas = 0
lin = 0
while lin < m:
    col = 0
    linha_e_nula = True
    while col < n:
        if matriz[lin][col] != 0:
            linha_e_nula = False
        col += 1
    if linha_e_nula:
        linhas_nulas += 1
    lin += 1

# Contando colunas nulas (todos os elementos da coluna são zero)
colunas_nulas = 0
col = 0
while col < n:
    lin = 0
    coluna_e_nula = True
    while lin < m:
        if matriz[lin][col] != 0:
            coluna_e_nula = False
        lin += 1
    if coluna_e_nula:
        colunas_nulas += 1
    col += 1

# Imprimindo a matriz
print('\nMatriz A:')
for lin in range(len(matriz)):
    for col in range(len(matriz[lin])):
        print(matriz[lin][col], end=' ')
    print()

# Resultado final
print(f'\nQuantidade de linhas nulas: {linhas_nulas}')
print(f'Quantidade de colunas nulas: {colunas_nulas}')