m = int(input('Entre com a dimensão da matriz: '))
matriz = []

for i in range(m):  #para cada linha na matriz
    linha = []
    print(f'Digite os elementos da linha {i}: ')
    for j in range(m): #para cada a coluna da matriz
        valor = int(input())
        linha.append(valor)
    matriz.append(linha)
#imprimindo a matriz
for i in range(m):
    for j in range(m):
        print(matriz[i][j], end=' ')
    print()

#encontrar o menor elemento da matriz e a sua linha
menor = matriz[0][0]
linha = 0
for i in range(m):
    for j in range(m):
        if matriz[i][j] < menor:
            menor = matriz[i][j]
            linha = i

maior = matriz[i][0]
coluna = 0

for col in range(m):
    if matriz[linha][col] > maior:
        maior = matriz[linha][col]
        coluna = col

print(f'MinMax = {matriz[linha][coluna]}')
print(f'Linha = {linha} Coluna = {coluna}')

