'''Faça um programa que inicialize uma matriz quadrada m x m. 
Em seguida, percorra a matriz verificando se é uma matriz identidade. 
Lembre-se de que em uma matriz identidade os elementos da diagonal principal são iguais a 1 e 
todos os demais elementos são iguais a zero, conforme o exemplo:

              1 0 0 0

Matriz = 0 1 0 0

              0 0 1 0

              0 0 0 1

'''

m = int(input('Entre com a dimensão da matriz: '))
matriz = []

for i in range(m):  #para cada linha na matriz
    linha = []
    print(f'Digite os elementos da linha {i}: ')
    for j in range(m): #para cada a coluna da matriz
        valor = int(input())
        linha.append(valor)
    matriz.append(linha)
#imprimindo a matriz
for i in range(m):
    for j in range(m):
        print(matriz[i][j], end=' ')
    print()

#verificando se a matriz é identidade 
identidade = True
i = 0

while i < len(matriz) and identidade == True:
    j = 0
    while j < len(matriz) and identidade == True:
        #verifica se o elemento da diagonal principal
        #é diferente de 1
        if i == j and matriz[i][j] != 1:
            identidade = False
        if i != j and matriz[i][j] != 0:
            identidade = False
        j+=1
    i += 1

if identidade:
    print('Matriz identidade')
else:
    print('Não é Matriz identidade')