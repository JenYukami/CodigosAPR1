'''Faça um programa que preencha uma matriz A de ordem m x n e um vetor V de tamanho n com 
valores inteiros. Em seguida, o programa deverá multiplicar cada linha de A por V 
criando um vetor R, conforme no exemplo dado a seguir:'''

m = int(input('Entre com o numero de linhas da matriz: '))
n = int(input('Entre com o numero de coluna da matriz: '))
A = []
for i in range(m):  #para cada linha na matriz
    linha = []
    print(f'Digite os elementos da linha {i}: ')
    for j in range(n): #para cada a coluna da matriz
        valor = int(input())
        linha.append(valor)
    A.append(linha)
#imprimindo a matriz
for i in range(m):
    for j in range(n):
        print(A[i][j], end=' ')
    print()

V = []
print('Digite os valores do vetor: ')
for i in range(n):
    valor= int(input())
    V.append(valor)
#imprimindo o vetor
for i in range(n):
    print(f'V[i]', end = ' ')

i = 0
R = []
while i < len(A):
    j = 0
    soma = 0
    while j < len(A[i]):
        soma = soma + A[i][j]*V[j]
        j+=1
    R.append(soma)
    i+=1 
print('\nElementos do vetor R: ')
for i in range(len(R)):
    print(f'{R[i]}', end=' ')