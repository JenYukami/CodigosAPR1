'''Faça um programa que crie duas listas A e B com valores inteiros, ambas de tamanho N. Em seguida, 
o programa deverá percorrer essas listas criando uma nova lista C que representará a intersecção de A e B. Ou seja, C conterá apenas os elementos comuns entre A e B. Por exemplo,
 para A = [1, 3, 6, 9, 12, 15, 18] e B = [1, 2, 4, 6, 8, 10, 12, 16], teremos:
C = [1,6,12] 
Ao final, o programa deverá imprimir os elementos de cada lista.
ps: Você não deve usar o operador in. Ao imprimir cada lista, você deverá imprimir somente 
os elementos e não a estrutura de lista. 

'''
A = []
i = 0
N = int(input('Informe a qualidade de elementos da lista: '))
print(f'Digite {N} elementos para lista A')
while i < N:
    valor = int(input())
    A.append(valor)
    i+=1

i = 0
B = []
while i < N:
    valor = int(input())
    B.append(valor)
    i += 1

C = []
i = 0
while i < N:
    j = 0
    while j < N:
        if A[i] == B[j]:
            C.append(A[i])
        j+=1
    i+=1
print('\nElementos do A: ')
for i in range(len(A)):
    print(f'{A[i]}', end=' ')

print('\nElementos do B: ')
for i in range(len(A)):
    print(f'{B[i]}', end=' ')

print('\nElementos do C: ')
for i in range(len(A)):
    print(f'{C[i]}', end=' ')