#Faça um programa que recebe uma frase e retorna o número de palavras 
#que a frase contém.

def converterfrase(palavrasemnumeros):
    i = 0
    espaço = 0
    while i < len(palavrasemnumeros):
        if palavrasemnumeros[i] == " ":
            espaço += 1
        i += 1
    print(f"Contém {espaço + 1} palavras nessa frase")


def main():
    frase = input('Digite sua frase: ')
    print(f"Sua frase é : {frase}")
    converterfrase(frase)
main()