# Faça um programa que solicite o nome do usuário e imprima-o na 
#vertical e em formato de escada.
def imprimirvertical(nome):
    i = 0
    for i in range(len(nome)):
        print(nome[0:i + 1])


def main():
    nome = input('Digite seu nome: ')
    imprimirvertical(nome)
main()