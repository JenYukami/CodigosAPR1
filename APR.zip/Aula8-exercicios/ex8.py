#Dada uma string com uma frase informada pelo usuário (incluindo
#espaços em branco), conte a quantidade de espaços em branco e a
#quantidade de vezes que aparecem as vogais a, e, i, o, u.

def qnt_espaços_vogais(verificadorfrase):
    vogais = 0
    espaços = 0
    i = 0

    while i < len(verificadorfrase):
        letra = verificadorfrase[i]
        if (letra == "a" or letra == "e" or letra == "i" or letra == "o" or letra == "u" or letra == "A" or letra == "E" or letra == "I" or letra == "O" or letra == "U"):
            vogais += 1

        if letra == " ":
            espaços += 1
        i += 1

    print(f'Total de vogais são {vogais}')
    print(f'Total de espaço são {espaços}')

    

def main():
    frase = input('Digite sua frase: ')
    print(f'Sua frase é: {frase}')
    qnt_espaços_vogais(frase)

main()