# Escreva um programa que verifique se duas strings fornecidas pelo 
#usuário são iguais e mostre o total de caracteres de cada uma delas. 
#Diferencie letras maiúsculas das minúsculas.

def comparar(palavraum, palavradois):
    if palavraum == palavradois:
        print('São iguais')

    else:
        print('Não são iguais')

def main():
    palavraum = input("Digite a primeira palavra ")
    palavradois = input("Digite a segunda palavra ")
    comparar(palavraum, palavradois)

    
    i = 0
    while i < len(palavraum):
        i += 1
    print(f'Total de caracteres da primeira palavra é {i}')

    i = 0
    while i < len(palavradois):
        i += 1
    print(f'Total de caracteres da segunda palavra é {i}')
    
main()