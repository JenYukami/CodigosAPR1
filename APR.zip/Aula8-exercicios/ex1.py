# Escreva um programa que remove a primeira ocorrência de uma letra de uma string. 
# A string e a letra devem ser fornecidas pelo usuário.

def primeiraocorrencia(palavranova):
    caractere=input("Digite um caractere a ser encontrado: ")
    indice = 0
    existe_letra = False
    while indice < len(palavranova) and not existe_letra:
        if palavranova[indice] == caractere:
             existe_letra = True
        indice = indice + 1

    if existe_letra:
        return palavranova[:indice] + palavranova[indice + 1:]
    else:
        return palavranova


    
def main():
    palavra = input('Digite sua palavra: ')
    print(primeiraocorrencia(palavra))
    
main()
