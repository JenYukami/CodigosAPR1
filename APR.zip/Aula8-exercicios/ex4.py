#Escreva um programa que reconhece se uma string é um palíndromo. 
#Exemplo: arara, ovo, reter

def palíndromo(palavracomparar):
    palavrainversa = ""
    i = len(palavracomparar) - 1
    while i >= 0:
        palavrainversa += palavracomparar[i]
        i -= 1
    print(f'O palídromo dessa palavra é {palavrainversa}')
    if palavracomparar == palavrainversa:
        print('Essa palavra é um palíndromo')
    else:
        print('Essa palavra não é um palíndromo')

def main():
    palavra = input("Digite uma palavra: ")
    palíndromo(palavra)
main()
