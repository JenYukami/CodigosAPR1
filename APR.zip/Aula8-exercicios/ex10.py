#Escreva um programa que solicite ao usuário a entrada de um número 
#inteiro positivo ou negativo e mostre a quantidade de dígitos desse 
#número

def quantidade(num):
    digito = '0123456789'
    i = 0
    if num[0] == '-' or num[0] == '+':
        i = 1
        while i <len(num):
            if num[i] in digito:
                cont+=1
        i+=1
    elif num[0] in digito:
        i = 0
    while i<len(num):
        if num[i] in digito:
            cont+=1
        i+=1
def main():
    numero = int(input("Digite seu número: "))
    quantidade(numero)
main()