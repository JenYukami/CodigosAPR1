#Faça um programa que permita ao usuário digitar o seu nome e em
#seguida o mostre de trás para frente utilizando somente letras
#maiúsculas

def invertidamaiuscula(nomeinvertidomaiusculo):
    palavra_inversa = ""
    i = len(nomeinvertidomaiusculo) - 1
    while i >= 0:
        palavra_inversa += nomeinvertidomaiusculo[i]
        i -= 1

    print(palavra_inversa.upper())


def main():
    nome = input('Digite seu nome: ')
    invertidamaiuscula(nome)
main()