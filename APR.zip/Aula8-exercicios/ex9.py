# Um anagrama é uma palavra que é feita a partir da transposição das 
# letras de outra palavra ou frase. Por exemplo, “Iracema” é um 
# anagrama para “America”. Escreva um programa que decida se uma 
# string é um anagrama de outra string, ignorando os espaços em branco. 
# O programa deve considerar maiúsculas e minúsculas como sendo 
# caracteres iguais, ou seja, “a” = “A”

def anagrama(str1,str2):
    str1 = str1.lower().replace(' ','')
    str2 = str2.lower().replace(' ','')
    if len(str1) == len(str2):
        anagrama = True
        i = 0
        while i < len(str1) and anagrama:
            cont1 = 0
            cont2= 0
            for  j in range(len(str1)): 
              if str1[i] == str1[j]:
                    cont1 += 1

            for j in range(len(str2)):
              if str1[i] == str2[j]:
                    cont2 += 1

            if cont1 != cont2:
                anagrama = False
            i += 1
        if anagrama:
            print("É anagrama")
        else:
            print("Não é um anagrama")
    else:
        print("Não é um anagrama")

def main():
    string1 = input("Digite sua primeira string: ")
    string2 = input("Digite sua segunda string: ")
    anagrama(string1, string2)
main()