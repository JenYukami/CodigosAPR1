#Escreva um programa que remove todas as ocorrências de uma letra de
#uma string. A string e a letra devem ser fornecidas pelo usuário.

def ocorrencia(palavranova):
    caractere = input('Digite a letra que queira remover: ')
    nova = ""
    indice = 0
    while indice < len(palavranova):
        if palavranova[indice] != caractere:
            nova += palavranova[indice]
        indice += 1
    return nova

def main():
    palavra = input('Digite uma palavra: ')
    print(ocorrencia(palavra))


main()