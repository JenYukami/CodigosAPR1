#Faça um programa que imprima os 20 primeiros números primos. 
num = 2
cont = 0
while cont < 20:
    primo = True
    divisor = 2
    while divisor < num:
        if num % divisor == 0:
          primo = False
        divisor += 1
    if primo:
       print(num)
       cont += 1
    num += 1