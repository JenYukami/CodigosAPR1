#Elabore um programa que efetue a soma de todos os números ímpares que são
#múltiplos de 3 e que se encontram no intervalo de 1 a 500. 
x = 0
soma = 0
while x <= 500:
    if x % 2 != 0 and x % 3 == 0:
        print(x)
        soma = soma + x
    x+=1
print(f'valor total da soma: {soma}')