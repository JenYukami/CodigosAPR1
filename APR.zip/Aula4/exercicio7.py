n = int(input('Quantos números você vai digitar? '))

original = []

for i in range(n):
    valor = int(input(f'Digite o número {i+1}: '))
    original.append(valor)

invertida = []

for i in range(len(original) - 1, -1, -1):
    invertida.append(original[i])

print(f'Sequência original: {original}')
print(f'Sequência invertida: {invertida}')