lista = []
i= 1
while i<=150:
    if i % 3 == 0:
        lista.append(i)
    i+=1
i=0
while i<len(lista):
    print(lista[i], end = ";")
    i+=1