notas = []
nota = 0
while nota>=0 and nota<=10:
    nota = float(input('Digite a nota: '))
    if nota>=0 and nota<=10:
        notas.append(nota)
    else:
        print('Encerra a entrada de notas.')

for i in range(len(notas)):
    print(notas[i])

soma = 0
i = 0
while i<len(notas):
    soma += notas[i]
    i+= i
media = soma/len(notas)
print(f'A média das notas = {media: .2f}')