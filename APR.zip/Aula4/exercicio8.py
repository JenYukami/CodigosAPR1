n = int(input('Quantos números você vai digitar? '))

original = []

for i in range(n):
    valor = int(input(f'Digite o número {i+1}: '))
    original.append(valor)

alterada = []

for valor in original:
    if valor % 2 == 0:
        alterada.append(1)
    else:
        alterada.append(-1)

print(f'Sequência original: {original}')
print(f'Sequência alterada: {alterada}')