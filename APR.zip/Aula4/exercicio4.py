n = int(input('Quantos números você vai digitar? '))

L = []

for i in range(n):
    valor = int(input(f'Digite o número {i+1}: '))
    L.append(valor)

sem_repeticao = []
repetidos = []

for valor in L:
    if valor in sem_repeticao:
        if valor not in repetidos: 
            repetidos.append(valor)
else:
        sem_repeticao.append(valor)

print(f'Lista original: {L}')
print(f'Lista sem repetição: {sem_repeticao}')
print(f'Lista com os repetidos: {repetidos}')