n = int(input('Quantos números você vai digitar? '))

original = []

for i in range(n):
    valor = int(input(f'Digite o número {i+1}: '))
    original.append(valor)

cubo = []

for valor in original:
    cubo.append(valor ** 3)

print(f'Sequência original: {original}')
print(f'Sequência ao cubo: {cubo}')