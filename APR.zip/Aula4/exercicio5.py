listaA = []
listaB = []
qtd = int(input("Informe o total de elementos que deseja: "))
cont = 1
print(f"Entre com {qtd} para a lista A: ")
while cont <= qtd:
    num = int(input())
    listaA.append(num)
    cont+= 1
cont = 1

print(f"Entre com {qtd} para a lista B: ")
while cont <= qtd:
    num = int(input())
    listaB.append(num)
    cont+=1
i = 0
print("Elementos da lista A: ")
while i < len(listaA):
    print(f"{listaA[i]}", end = '')
    i+= 1 
print("Elementos da lista B: ")
for i in range(len(listaB)):
    print(f"{listaB[i]}", end = '')

listaC = []
i = 0 
while i < qtd:
    result = listaA[i] + listaB[i]
    listaC.append(result)
    i+=1

print("Elementos da lista C: ")
for i in range(len(listaC)):
    print(f"{listaC[i]}", end = '')

