n = int(input())
l1 = []
i = 0

print(f'Entre com os {n} valores inteiros')
while i < n:
    valor = int(input())
    l1.append(valor)
    i+=1
l2 = []
l3 = []

for i in range(len(l1)):
    if len(l2) == 0:
        l2.append(l1[i])
    else:
        achou = False
        while j < len(l2) and not achou:
            if l1[i] == l2[j]:
                achou = True
            j+=1 #Sempre dentro do laço while, dentro do for não precisa
            if achou == True:
                l3.append(l1[i])
            else:
                l2.append(l1[i])
print('Elementos da lista 1:')
for i in range(len(l1)):
    print(f'{l1[i]}', end = '')
print('\nElementos da lista 2:')
i = 0
while i<len(l2):
    print(f'{l2[i]}', end = '')
    i += 1
print('\nElementos da lista 3:')
while i<len(l3):
    print(f'{l3[i]}', end = '')
    i += 1
