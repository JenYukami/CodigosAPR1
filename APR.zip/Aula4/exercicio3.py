N = int(input('Quantos valores deseja na sequência: '))
lista = []
cont = 1
print(f'Digite {N} valores inteiros: ')
while cont <= N:
    numero = int(input())
    lista.append(numero)
    cont+=1

soma = 0
produto = 1 #O produto não pode ser 0
i=0
while i<len(lista):
    if lista[i]%2 == 0:
        soma+=lista[i]
    else:
        produto *= lista[i]
    i+=1
for i in range(len(lista)):
    print(lista[i])
print(f'Somatória dos pares = {soma}')
print(f'Produtoria dos valores impares = {produto}')