L = [2,5,9,7,8,2,5,12,24,33,7,7]
valor = int(input('Digite um valor para procurar'))
i = 0
achou = False
while i<len(L) and achou == False:
    if valor == L(i):
        achou = True
    i+=1
if achou == True:
    print('Valor encontrado na lista')
else:
    print('Valor não encontrado')

#Resolver depois com calma em casa tem haver com exercicio 4