def e_de_maior(moradores, cidade):
    L = []
    for i in range(len(moradores)):
        idade = moradores[i][2]
        if idade >= 18 and moradores[i][1] == cidade :
            L.append(moradores[i][0].upper())
    return L

def main():
    pessoas = []
    quantidade = int(input('Digite a quantidade de pessoas: '))
    for i in range(quantidade):
        nome = input('Digite o nome da pessoa: ')
        cidade = input('Digite o nome da cidade: ')
        idade = int(input('Digite a idade: '))
        pessoas.append([nome, cidade, idade])
    print(e_de_maior(pessoas, 'São Carlos'))
main()