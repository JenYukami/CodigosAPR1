def estoque(item):
    L = []
    total = 0
    for i in range(len(item)):
        valor = item[i][1] * item[i][2]
        total = total + valor
    L.append(total)
    return L
        

def main():
    produto = [['Caneta', 3, 100], ['Mochila', 120, 10], ['Caderno', 25, 50]]
    print(estoque(produto))
main()