'''Escreva inverter(texto), 
que retorna o texto de trás para frente.'''

def inverter(texto):
    novo = ''
    i = len(texto) - 1
    while i >= 0:
        novo += texto[i]
        i -= 1
    return novo



def main():
    palavra = 'abc'
    print(inverter(palavra))
main()