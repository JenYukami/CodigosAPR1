'''Escreva media(lista), que retorna a média dos números.'''

def media(notas):
    total = 0
    for i in range(len(notas)):
        total = total + notas[i]
    return total/ len(notas)

def main():
    numero = [7, 8, 9, 10]
    print(media(numero))
main()