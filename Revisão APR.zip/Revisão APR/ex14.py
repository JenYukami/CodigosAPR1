'''Escreva palindromas(palavras), que recebe uma lista de strings e 
retorna uma lista só com as palavras que são palíndromas.'''
def e_palindromo(lista):
    novo = ''
    i = len(lista) - 1
    while i >= 0:
        novo += lista[i]
        i -= 1
    return novo == lista

def palindromo(palavra):
    l = []
    for i in range(len(palavra)):
        if e_palindromo(palavra[i]):
            l.append(palavra[i])
    return l 

def main():
    lista = ['osso', 'casa', 'arara', 'sol', 'ovo']
    print(palindromo(lista))
main()