def aprovados(estudantes):
    L = []
    for i in range(len(estudantes)):
        media = (estudantes[i][1] + estudantes[i][2]) / 2
        if media >= 6:
            L.append(estudantes[i][0])
    
    return L


def main():
    alunos = []
    quantidade = int(input('Quantos alunos: '))
    for i in range(quantidade):
        nome = input('Nome do aluno: ')
        nota1 = float(input('Nota 1: '))
        nota2 = float(input('Nota 2: '))
        alunos.append([nome, nota1, nota2])
    print(aprovados(alunos))
main()