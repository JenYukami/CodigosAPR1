'''Escreva e_palindromo_frase(texto), que retorna True se o texto é palíndromo, sem diferenciar maiúscula de minúscula e ignorando os espaços.'''

def e_palindromo_frase(texto):
    texto = texto.lower()
    limpo = ''
    for i in range(len(texto)):
        if texto[i] != ' ':
            limpo += texto[i]
    novo = ''
    i = len(limpo) - 1
    while i >= 0:
        novo += limpo[i]
        i -= 1
    print(f'palindromo dessa frase/palavra: {novo}')

    if novo == limpo:
        return True
    else:
        return False



def main():
    frase = input('Digite uma frase: ')
    print(e_palindromo_frase(frase))
main()