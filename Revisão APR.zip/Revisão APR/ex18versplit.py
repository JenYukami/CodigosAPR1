def contracoes(lista):
    i = 0
    j = len(lista) - 1
    ops = 0
    while i < j:
        if lista[i] == lista[j]:
            i = i + 1
            j = j - 1
        elif lista[i] < lista[j]:
            lista[i + 1] = lista[i + 1] + lista[i]
            i = i + 1
            ops = ops + 1
        else:
            lista[j - 1] = lista[j - 1] + lista[j]
            j = j - 1
            ops = ops + 1
    return ops

def main():
    n = int(input())
    partes = input().split()
    lista = []
    for i in range(n):
        lista.append(int(partes[i]))
    print(contracoes(lista))
main()