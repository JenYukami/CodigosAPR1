'''Escreva soma_coluna(matriz, j), que retorna 
a soma dos elementos da coluna j.'''

def soma_coluna(matriz, j):
    total = 0
    for i in range(len(matriz)):
        total = total + matriz[i][j]
    return total



def main():
    matriz = [[1, 2, 3],[4, 5, 6],[7, 8, 9]]
    print(soma_coluna(matriz, 1))
main()