def menor_c(a, b):
    menor = a
    if b < a:
        menor = b
    maior = a + b - menor
    return 2 * menor - maior

def main():
    partes = input().split()
    a = int(partes[0])
    b = int(partes[1])
    print(menor_c(a, b))
main()