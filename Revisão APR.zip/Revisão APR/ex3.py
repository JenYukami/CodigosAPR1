'''Cada linha é [nome, preço, quantidade]. Escreva produtos_caros(produtos, limite), 
que retorna a lista com os nomes dos produtos cujo preço é maior que o limite.'''

def caro(item, limite):
    L = []
    for i in range(len(item)):
        if item[i][1] > limite:
            L.append(item[i][0])
    return L

def main():
    produto = [['Caneta', 3, 100], ['Mochila', 120, 10], ['Caderno', 25, 50]]
    print(caro(produto, 20))
main()