def somalinha(soma):
    matriz = []
    for i in range(len(soma)):
        total = 0
        for j in range(len(soma[i])):
            total = total + soma[i][j]
        matriz.append(total)
    return matriz



def main():
    linha = [[1, 2, 3], [4, 5, 6], [7, 8, 9]]
    print(somalinha(linha))
main()