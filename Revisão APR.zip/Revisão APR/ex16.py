def soma_rec(L,k):
    if k == 0:
        return L[0]
    return soma_rec(L, k-1) + L[k]


def main():
    L = [3, 5, 2, 10]
    result = soma_rec(L, len(L) - 1)
    print(result)
main()