def aprovados(estudantes):
    L = []
    for i in range(len(estudantes)):
        media = (estudantes[i][1] + estudantes[i][2]) / 2
        if media >= 6:
            L.append(estudantes[i][0])
    
    return L


def main():
    alunos = [['Ana', 7, 8], ['Bruno', 5, 4], ['Carla', 9, 10]]
    print(aprovados(alunos))
main()