def buscar(produtos, codigo):
    pos = -1
    for i in range(len(produtos)):
        if produtos[i][0] == codigo:
            pos = i
    return pos

def incluir(produtos, codigo, nome, preco):
    if buscar(produtos, codigo) != -1:
        print('Este produto ja esta cadastrado')
        return -1
    produtos.append([codigo, nome, preco])
    pos = len(produtos) - 1
    print('Produto cadastrado')
    return pos

def excluir(produtos, codigo):
    pos = buscar(produtos, codigo)
    if pos == -1:
        print('Produto não encontrado')
        return -1
    del produtos[pos]
    return pos

def alterar(produtos, codigo, novo_nome, novo_preco):
    pos = buscar(produtos, codigo)
    if pos == - 1:
        print('Produto não encontrado')
        return -1
    produtos[pos][1] = novo_nome
    produtos[pos][2] = novo_preco
    return pos

def main():
    produtos = [['1', 'Caneta', 3],['2', 'Caderno', 25]]
    print(incluir(produtos, '3', 'Mochila', 120))
    print(produtos)
    print(incluir(produtos, '1', 'Lápis', 2))
    print(excluir(produtos, '2'))
    print(produtos)
    print(excluir(produtos, '9'))
    print(alterar(produtos,'1', 'Lápis', 2))
    print(produtos)
    print(alterar(produtos, '9', 'X', 1))
main()