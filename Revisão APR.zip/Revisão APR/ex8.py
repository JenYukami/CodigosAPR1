'''Escreva soma_pares(lista), que retorna 
a soma só dos números pares da lista.'''

def soma_pares(lista):
    total = 0
    for i in range(len(lista)):
        if lista[i] % 2 == 0:
            total = total + lista[i]
    return total


def main():
    numeros = [1, 2, 3, 4, 5, 6]
    print(soma_pares(numeros))
main()