def e_de_maior(moradores, cidade):
    L = []
    for i in range(len(moradores)):
        idade = moradores[i][2]
        if idade >= 18 and moradores[i][1] == cidade :
            L.append(moradores[i][0].upper())
    return L

def main():
    pessoas = [['Ana', 'São Carlos', 20], ['Bruno', 'Araraquara', 17], ['Carla', 'São Carlos', 25], ['Diego', 'São Carlos', 16]]
    print(e_de_maior(pessoas, 'São Carlos'))
main()