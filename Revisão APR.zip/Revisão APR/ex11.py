'''Escreva soma_diagonal(matriz), que retorna a 
soma da diagonal principal de uma matriz quadrada.'''

def soma_diagonal(matriz):
    total = 0
    for i in range(len(matriz)):
        for j in range(len(matriz[i])):
            if i == j:
                total = total + matriz[i][j]
    return total

def main():
    matriz = [[1, 2, 3], [4, 5, 6], [7, 8, 9]]
    print(soma_diagonal(matriz))
main()