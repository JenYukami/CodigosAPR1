'''Cada linha é [nome, cidade]. Escreva nomes_com_inicial(pessoas, letra, cidade), 
que retorna os nomes que começam com a letra e moram na cidade.'''

def nomes_com_inicial(pessoas, letra, cidade):
    L = []
    for i in range(len(pessoas)):
        if pessoas[i][0][0] == letra and pessoas[i][1] == cidade:
            L.append(pessoas[i][0])
    return L

def main():
    pessoas = [['Ana', 'Rio'], ['Alberto', 'Rio'], ['Amanda', 'Recife'], ['Bia', 'Rio']]
    print(nomes_com_inicial(pessoas, 'A', 'Rio'))
main()