def caro(item, limite):
    L = []
    for i in range(len(item)):
        if item[i][1] > limite:
            L.append(item[i][0])
    return L

def main():
    produto = []
    qnt = int(input('Digite a quantidade de produtos: '))
    for i in range(qnt):
        nomeproduto = input('Digite o nome do produto: ')
        preco = int(input('Digite o preço do produto: '))
        qnt_produto = int(input('Digite a quantidade desse produto disponivel: '))
        produto.append([nomeproduto, preco, qnt_produto])
    print(caro(produto, 20))
main()