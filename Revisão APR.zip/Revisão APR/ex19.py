'''Desafio 2: Baralho

Para cada naipe, percorro as cartas de 3 em 3 caracteres, guardo os valores já vistos e marco duplicada se um valor 
se repetir. No fim, se houver duplicada o resultado é erro, e senão são 13 - quantidade.'''

def baralho(cartas):
    naipes = ['C', 'E', 'U', 'P']
    resultado = []
    for n in range(4):
        vistas = []
        duplicada = False
        for i in range(0, len(cartas), 3):
            valor = cartas[i] + cartas[i + 1]
            naipe = cartas[i + 2]
            if naipe == naipes[n]:
                for k in range(len(vistas)):
                    if vistas[k] == valor:
                        duplicada = True
                vistas.append(valor)
        if duplicada:
            resultado.append('erro')
        else:
            resultado.append(str(13 - len(vistas)))
    return resultado

def main():
    cartas = input()
    resultado = baralho(cartas)
    for i in range(len(resultado)):
        print(resultado[i])
main()