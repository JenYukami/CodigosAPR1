'''Desafio 3: Cifra da Nlogônia

Montei três strings alinhadas por posição: a consoante, a vogal mais próxima dela e a consoante seguinte. 
Se a letra é a consoante da posição j, ela vira letra + vogal_proxima[j] + consoante_seguinte[j]. Se não 
achar a letra na lista, é vogal e fica igual.'''

def cifrar(palavra):
    consoantes         = "bcdfghjklmnpqrstvxz"
    vogal_proxima      = "aaeeeiiiiooooouuuuu"
    consoante_seguinte = "cdfghjklmnpqrstvxzz"
    resultado = ""
    for i in range(len(palavra)):
        letra = palavra[i]
        achou = False
        for j in range(len(consoantes)):
            if letra == consoantes[j]:
                resultado = resultado + letra + vogal_proxima[j] + consoante_seguinte[j]
                achou = True
        if not achou:
            resultado = resultado + letra
    return resultado

def main():
    palavra = input()
    print(cifrar(palavra))
main()