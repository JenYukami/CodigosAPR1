def somalinha(soma):
    matriz = []
    for i in range(len(soma)):
        total = 0
        for j in range(len(soma[i])):
            total = total + soma[i][j]
        matriz.append(total)
    return matriz



def main():
    matriz = []
    linhas = int(input('Digite quantas linhas: '))
    colunas = int(input('Digite quantas colunas: '))
    for i in range(linhas):
        linha = []
        for j in range(colunas):
            numero = int(input(f'Elemento [{i}][{j}]: '))
            linha.append(numero)
        matriz.append(linha)
    print(somalinha(matriz))
main()