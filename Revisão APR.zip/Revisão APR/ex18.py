'''Desafio 4: Lista palíndroma

Uso dois ponteiros, um no começo e outro no fim. Se os valores são iguais, ando os dois para dentro. 
Se são diferentes, somo o menor com o vizinho dele (uma contração), porque assim aproximo os dois lados. 
Como todos os números são positivos, esse jeito dá o mínimo.'''


def dividir(texto):
    partes = []
    atual = ''
    for i in range(len(texto)):
        if texto[i] == ' ':
            if atual != '':
                partes.append(atual)
                atual = ''
        else:
            atual = atual + texto[i]
    if atual != '':
        partes.append(atual)
    return partes

def contracoes(lista):
    i = 0
    j = len(lista) - 1
    ops = 0
    while i < j:
        if lista[i] == lista[j]:
            i = i + 1
            j = j - 1
        elif lista[i] < lista[j]:
            lista[i + 1] = lista[i + 1] + lista[i]
            i = i + 1
            ops = ops + 1
        else:
            lista[j - 1] = lista[j - 1] + lista[j]
            j = j - 1
            ops = ops + 1
    return ops

def main():
    n = int(input())
    partes = dividir(input())
    lista = []
    for i in range(n):
        lista.append(int(partes[i]))
    print(contracoes(lista))
main()