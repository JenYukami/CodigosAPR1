'''Desafio 1: Média e Mediana

A ideia é que a mediana de A, B e C pode ser A, B ou C, e o menor C possível acontece quando A (o menor)
é a mediana. Nesse caso a média também vale A, então (A + B + C) / 3 = A e C = 2A - B.'''


def dividir(texto):
    partes = []
    atual = ''
    for i in range(len(texto)):
        if texto[i] == ' ':
            if atual != '':
                partes.append(atual)
                atual = ''
        else:
            atual = atual + texto[i]
    if atual != '':
        partes.append(atual)
    return partes

def menor_c(a, b):
    menor = a
    if b < a:
        menor = b
    maior = a + b - menor
    return 2 * menor - maior

def main():
    partes = dividir(input())
    a = int(partes[0])
    b = int(partes[1])
    print(menor_c(a, b))
main()