'''Uma palavra é palíndroma quando ela é igual à sua inversa. 
Você acabou de escrever a ferramenta que falta. Tenta fazer eh_palindromo(texto) usando a sua função inverter:'''

def e_palindromo(texto):
    novo = ''
    i = len(texto) -1
    
    while i >= 0:
        novo += texto[i]
        i -= 1
    print(f'A palindromo dessa palavra é {novo}')

    if novo == texto:
        return True
    else:
        return False

def main():
    palavra = input('Digite uma palavra: ')
    print(e_palindromo(palavra))
main()