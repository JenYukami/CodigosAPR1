'''Escreva conta_vogais(texto), 
que retorna quantas vogais (a, e, i, o, u) existem no texto, sem diferenciar maiúscula de minúscula.'''

def conta_vogais(texto):
    cont = 0
    texto = texto.lower()
    for i in range(len(texto)):
        letra = texto[i]
        if letra == 'a' or letra == 'e' or letra == 'i' or letra == 'o' or letra == 'u':
            cont += 1
    return cont 

def main():
    palavra = input('Digite uma palavra: ')
    print(conta_vogais(palavra))
main()